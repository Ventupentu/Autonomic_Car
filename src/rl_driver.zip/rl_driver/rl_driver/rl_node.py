import rclpy
from rclpy.node import Node

from std_msgs.msg import Float32, String
from geometry_msgs.msg import Point
from auria_msgs.msg import PointArray

from stable_baselines3 import PPO
import numpy as np
import os

class RLDriverNode(Node):
    def __init__(self):
        super().__init__('rl_node')

        self.model_path = os.path.expanduser('./ppo_ros2_car.zip')
        if not os.path.exists(self.model_path):
            self.get_logger().error(f'Model not found at {self.model_path}')
            exit(1)

        self.model = PPO.load(self.model_path)
        self.get_logger().info('Modelo cargado correctamente.')

        # Subscripciones
        self.sub_yaw = self.create_subscription(Float32, '/can/yaw', self.yaw_callback, 10)
        self.sub_speed = self.create_subscription(Float32, '/can/speed', self.speed_callback, 10)
        self.sub_blue_cones = self.create_subscription(PointArray, '/vision/nearby_cones/blue', self.blue_callback, 10)
        self.sub_yellow_cones = self.create_subscription(PointArray, '/vision/nearby_cones/yellow', self.yellow_callback, 10)

        # Publicadores
        self.pub_steering = self.create_publisher(Float32, '/car/steering', 10)
        self.pub_accel = self.create_publisher(Float32, '/car/acceleration', 10)
        self.pub_state = self.create_publisher(String, '/car/state', 10)

        # Estado interno
        self.yaw = 0.0
        self.speed = 0.0
        self.blue_cones = []
        self.yellow_cones = []

        self.timer = self.create_timer(0.1, self.control_loop)

    def yaw_callback(self, msg):
        self.yaw = msg.data

    def speed_callback(self, msg):
        self.speed = msg.data

    def blue_callback(self, msg):
        self.blue_cones = [(p.x, p.y) for p in msg.points]

    def yellow_callback(self, msg):
        self.yellow_cones = [(p.x, p.y) for p in msg.points]

    def control_loop(self):
        # Solo actuamos si hay conos visibles
        if not self.blue_cones or not self.yellow_cones:
            return

        obs = self.construct_observation()
        action, _ = self.model.predict(obs, deterministic=True)

        steering = Float32()
        accel = Float32()
        steering.data = float(action[0])
        accel.data = float(action[1])

        self.pub_steering.publish(steering)
        self.pub_accel.publish(accel)

        # Criterio básico para terminar (ajustar según el entorno)
        if self.speed < 0.5 and len(self.blue_cones) + len(self.yellow_cones) < 4:
            msg = String()
            msg.data = 'finish'
            self.pub_state.publish(msg)
            self.get_logger().info('Fin de la pista detectado. Enviando estado "finish".')

    def construct_observation(self):
        # Observación: 6 valores: yaw, speed + primeros 2 conos de cada tipo (x, y)
        obs = [self.yaw, self.speed]

        for cones in [self.blue_cones, self.yellow_cones]:
            for i in range(2):
                if i < len(cones):
                    obs.extend([cones[i][0], cones[i][1]])
                else:
                    obs.extend([0.0, 0.0])  # padding

        return np.array(obs, dtype=np.float32)

def main(args=None):
    rclpy.init(args=args)
    node = RLDriverNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
