import gymnasium as gym
from gymnasium import spaces
import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32, String
from auria_msgs.msg import PointArray
from geometry_msgs.msg import Point

class Ros2CarEnv(gym.Env):
    def __init__(self):
        super(Ros2CarEnv, self).__init__()

        # Inicializar ROS 2
        rclpy.init()

        # Nodo ROS 2
        self.node = Node('ros2_car_env')

        # Variables para controlar el coche
        self.steering_pub = self.node.create_publisher(Float32, '/car/steering', 10)
        self.accel_pub = self.node.create_publisher(Float32, '/car/acceleration', 10)
        self.state_pub = self.node.create_publisher(String, '/car/state', 10)

        # Suscriptores de información sobre el entorno (conos, velocidad, posición, etc.)
        self.cones_sub = self.node.create_subscription(PointArray, '/vision/all_cones/blue', self.cones_callback, 10)
        self.speed_sub = self.node.create_subscription(Float32, '/can/speed', self.speed_callback, 10)
        self.car_position_sub = self.node.create_subscription(Point, '/env/car_position', self.position_callback, 10)

        # Espacios de acción y observación
        self.action_space = spaces.Box(low=np.array([-1.0, -1.0]), high=np.array([1.0, 1.0]), dtype=np.float32)  # Steering y aceleración
        self.observation_space = spaces.Box(low=np.array([-10.0, -10.0]), high=np.array([10.0, 10.0]), dtype=np.float32)  # Posición y velocidad

        self.car_position = None
        self.speed = None
        self.cones = []

    def cones_callback(self, msg):
        self.cones = msg.points

    def speed_callback(self, msg):
        self.speed = msg.data

    def position_callback(self, msg):
        self.car_position = np.array([msg.x, msg.y])

    def reset(self, seed=None, **kwargs):
        # Resetea el entorno, por ejemplo, poniendo el coche en su posición inicial
        self.car_position = np.array([0.0, 0.0])  # Ejemplo: posición del coche en (0,0)
        self.speed = 0.0  # Ejemplo: velocidad inicial
        self.cones = []  # Conos en el entorno

        # Publica el estado de inicio
        state_msg = String()
        state_msg.data = 'start'
        self.state_pub.publish(state_msg)

        # Si el modelo tiene algún comportamiento aleatorio basado en el seed
        if seed is not None:
            np.random.seed(seed)

        # Devuelve solo la observación como un único valor
        # Esto podría ser una combinación de la posición del coche, velocidad, etc.
        observation = np.concatenate([self.car_position, [self.speed]])

        return observation

    def step(self, action):
        # Acciones: [steering, acceleration]
        steering, acceleration = action

        # Publica los comandos al coche
        steering_msg = Float32()
        steering_msg.data = steering
        self.steering_pub.publish(steering_msg)

        accel_msg = Float32()
        accel_msg.data = acceleration
        self.accel_pub.publish(accel_msg)

        # Se asume que la dinámica del coche está controlada externamente por ROS
        # Ahora, observa el estado después de realizar la acción

        # Esperamos a obtener la nueva posición y velocidad del coche
        rclpy.spin_once(self.node)  # Esto es crucial para que el nodo ROS reciba los mensajes y se actualicen las variables

        observation = np.concatenate([self.car_position, [self.speed]])

        # Calculamos la recompensa en función de la distancia al objetivo o la cercanía de los conos
        reward = -self.get_distance_to_nearest_cone()  # Ejemplo de cálculo de recompensa basado en la distancia a los conos

        # Determinamos si hemos llegado al final del circuito
        done = False
        if self.car_position[0] > 10.0:  # Este es solo un ejemplo, usa la lógica del circuito real
            done = True
            state_msg = String()
            state_msg.data = 'finish'
            self.state_pub.publish(state_msg)

        return observation, reward, done, {}

    def get_distance_to_nearest_cone(self):
        if not self.cones:
            return float('inf')

        # Calculamos la distancia mínima a cualquier cono
        distances = np.linalg.norm(np.array([[cone.x, cone.y] for cone in self.cones]) - self.car_position, axis=1)
        return np.min(distances)

    def render(self, mode='human'):
        # Aquí puedes agregar la visualización del entorno (opcional)
        pass

    def close(self):
        # Cierra el nodo de ROS
        self.node.destroy_node()
        rclpy.shutdown()
