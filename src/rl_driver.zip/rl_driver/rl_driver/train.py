from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from rl_driver.gym_ros2_env import Ros2CarEnv

# Crear el entorno ROS 2
def make_env():
    env = Ros2CarEnv()
    return env

# Hacer un entorno vectorizado con DummyVecEnv
env = DummyVecEnv([make_env])

# Entrenar el modelo
model = PPO("MlpPolicy", env, verbose=1)
model.learn(total_timesteps=100000)
